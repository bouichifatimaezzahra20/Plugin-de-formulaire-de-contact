<?php
/*
Plugin Name: Contact Form Plugin
Version: 1.0
Description: A custom contact form plugin for WordPress.
Author: fati fati
*/
add_action('admin_menu', 'register_contact_form_menu');
function register_contact_form_menu() {
    add_menu_page('Contact Form Plugin', 'Contact Form', 'manage_options', 'contact-form', 'contact_form_page');
}
// Create the "wp_contact_form" table in the database when activating the plugin
register_activation_hook(__FILE__, 'create_contact_form_table');
function create_contact_form_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'contact_form';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id int(11) NOT NULL AUTO_INCREMENT,
        sujet varchar(255) NOT NULL,
        nom varchar(255) NOT NULL,
        prenom varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        message text NOT NULL,
        date_envoi datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        PRIMARY KEY  (id)
    ) $charset_collate;";
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}

// Delete the "wp_contact_form" table from the database when deactivating the plugin:
    register_deactivation_hook(__FILE__, 'delete_contact_form_table');
function delete_contact_form_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'contact_form';
    $sql = "DROP TABLE IF EXISTS $table_name";
    $wpdb->query($sql);
}
// create a shortcode that will display the form
add_shortcode('contact_form', 'contact_form_shortcode');
function contact_form_shortcode() {
    // Code pour afficher le formulaire
    $output = '<form method="post" action="">';
    $output .= '<div>';
    $output .= '<label for="sujet">Sujet :</label>';
    $output .= '<input type="text" name="sujet" required>';
    $output .= '</div>';
    $output .= '<div>';
    $output .= '<label for="nom">Nom :</label>';
    $output .= '<input type="text" name="nom" required>';
    $output .= '</div>';
    $output .= '<div>';
    $output .= '<label for="prenom">Prénom :</label>';
    $output .= '<input type="text" name="prenom" required>';
    $output .= '</div>';
    $output .= '<div>';
    $output .= '<label for="email">Email :</label>';
    $output .= '<input type="email" name="email" required>';
    $output .= '</div>';
    $output .= '<div>';
    $output .= '<label for="message">Message :</label>';
    $output .= '<textarea name="message" required></textarea>';
    $output .= '</div>';
    $output .= '<div>';
    $output .= '<input type="submit" name="submit" value="Envoyer">';
    $output .= '</div>';
    $output .= '</form>';

    return $output;
}
// insert form data into "wp_contact_form" table
if(isset($_POST['submit'])) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'contact_form';
    $date_envoi = current_time('mysql');
    $data = array(
        'sujet' => $_POST['sujet'],
        'nom' => $_POST['nom'],
        'prenom' => $_POST['prenom'],
        'email' => $_POST['email'],
        'message' => $_POST['message'],
        'date_envoi' => $date_envoi
    );
    $wpdb->insert($table_name, $data);
    // Afficher un message de succès
    
}
// add css
$output .= '<style>
form {
    width: 500px;
    margin: auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  
  div {
    margin-bottom: 10px;
  }
  
  label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
  }
  
  input[type="text"],
  input[type="email"],
  textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  
  input[type="submit"] {
    background-color: #0073aa;
    color: #fff;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    cursor: pointer;
  }
  
  input[type="submit"]:hover {
    background-color: #005d8f;
  }
';  
// add menu admin page
function contact_form_plugin_menu() {
    add_menu_page(
        'Contact Form Plugin',
        'Contact Form Plugin',
        'manage_options',
        'contact-form-plugin',
        'contact_form_plugin_page'
    );
}
add_action('admin_menu', 'contact_form_plugin_menu');
    // This function will display the contents of the admin menu page
function contact_form_plugin_page() {
    ?>
    <div class="wrap">
        <h1>Contact Form Plugin</h1>
        <p>Welcome to the Contact Form Plugin admin page. Here you can manage your contact form settings.</p>
        <form method="post" action="options.php">
            <?php
                settings_fields('contact_form_settings');
                do_settings_sections('contact_form_settings');
                submit_button('Save Settings');
            ?>
        </form>
    </div>
    <?php
}
?>